import pandas as pd, numpy as np
from style import *
p=pd.read_pickle('plants.pkl')
up=p.nlargest(12,'shift'); dn=p.nsmallest(12,'shift')
d=pd.concat([dn.sort_values('shift'),up.sort_values('shift')])
fig,ax=plt.subplots(figsize=(12,8.4)); fig.subplots_adjust(top=0.82,left=0.06,right=0.97,bottom=0.12)
cols=[S1 if s>0 else S2 for s in d['shift']]
ax.barh(range(len(d)),d['shift'],color=cols,height=0.6)
ax.set_yticks([])
for i,(sh,nm,rp,rv,pc,vol) in enumerate(zip(d['shift'],d.Nama_Loji,d.rank_pct,d.rank_vol,d.nrw_pct,d.nrw_yr)):
    if sh>0:
        ax.text(-3,i,nm,va='center',ha='right',fontsize=9,color=INK)
        ax.text(sh+3,i,f'rate #{rp} → volume #{rv}   ·   {pc:.0f}%  ·  {vol/1e6:.1f}M m³/yr',va='center',ha='left',fontsize=8.5,color=SEC)
    else:
        ax.text(3,i,nm,va='center',ha='left',fontsize=9,color=INK)
        ax.text(sh-3,i,f'{vol/1e6:.1f}M m³/yr  ·  {pc:.0f}%   ·   rate #{rp} → volume #{rv}',va='center',ha='right',fontsize=8.5,color=SEC)
ax.axvline(0,color=AX,lw=1)
ax.set_xlim(-125,125); ax.set_xticks([-75,-50,-25,0,25,50,75]); ax.set_xticklabels(['75','50','25','0','25','50','75'])
ax.set_xlabel('Places moved between the two rankings')
ax.grid(axis='x'); ax.set_axisbelow(True); ax.spines['left'].set_visible(False); ax.spines['bottom'].set_visible(False)
ax.text(-122,len(d)-0.1,'← rate ranks it urgent, volume does not',fontsize=9.5,color=S2,fontweight='bold')
ax.text(122,len(d)-0.1,'volume ranks it urgent, rate does not →',fontsize=9.5,color=S1,fontweight='bold',ha='right')
frame(fig,ax,'The plants that move furthest between the two rankings',
 'Twelve largest movers in each direction. SEMAMBU is last of 74 on rate (27.2%) yet 4th on volume: switching measure\nmoves it 70 places. KARAK INDAH does the reverse — 2nd on rate, 69th on volume, on 0.3M m³ a year.',ty=1.16,sy=1.115,srcy=-0.14)
fig.savefig('fig4_rank_shift.png')
