import pandas as pd, numpy as np
from style import *
p=pd.read_pickle('plants.pkl').copy()
fig,ax=plt.subplots(figsize=(8.6,10))
fig.subplots_adjust(top=0.86,bottom=0.08)
topv=set(p.nsmallest(10,'rank_vol').Nama_Loji); topp=set(p.nsmallest(10,'rank_pct').Nama_Loji)
for _,r in p.iterrows():
    hl = r.Nama_Loji in topv or r.Nama_Loji in topp
    c = S1 if r.Nama_Loji in topv else (S2 if r.Nama_Loji in topp else NEUT)
    ax.plot([0,1],[r.rank_pct,r.rank_vol],color=c,lw=2 if hl else 1.0,alpha=1 if hl else .55,zorder=4 if hl else 2,solid_capstyle='round')
    ax.scatter([0,1],[r.rank_pct,r.rank_vol],s=34 if hl else 16,c=c,edgecolors=SURF,linewidths=1.4,zorder=5 if hl else 3)
for _,r in p.iterrows():
    if r.Nama_Loji in topp:
        ax.text(-0.035,r.rank_pct,f'{r.rank_pct}  {r.Nama_Loji}',ha='right',va='center',fontsize=8.5,color=SEC)
        ax.text(1.035,r.rank_vol,f'{r.Nama_Loji}  {r.rank_vol}',ha='left',va='center',fontsize=8.5,color=MUT)
    if r.Nama_Loji in topv:
        ax.text(1.035,r.rank_vol,f'{r.rank_vol}  {r.Nama_Loji}',ha='left',va='center',fontsize=8.5,color=SEC)
        ax.text(-0.035,r.rank_pct,f'{r.Nama_Loji}  {r.rank_pct}',ha='right',va='center',fontsize=8.5,color=MUT)
ax.invert_yaxis(); ax.set_xlim(-0.55,1.55); ax.set_ylim(76,-6)
ax.axis('off')
ax.text(0,-3.6,'RANKED BY NRW RATE %',ha='center',fontsize=9.5,fontweight='bold',color=S2)
ax.text(1,-3.6,'RANKED BY NRW VOLUME',ha='center',fontsize=9.5,fontweight='bold',color=S1)
ax.text(0,76.5,'worst rate at top  ·  rank 1–74',ha='center',fontsize=8,color=MUT)
ax.text(1,76.5,'largest volume at top  ·  rank 1–74',ha='center',fontsize=8,color=MUT)
from matplotlib.lines import Line2D
ax.legend(handles=[Line2D([],[],color=S1,lw=2.4,label='Top 10 by NRW volume'),
                   Line2D([],[],color=S2,lw=2.4,label='Top 10 by NRW rate %'),
                   Line2D([],[],color=NEUT,lw=1.4,label='Other plants')],
          loc='lower center',bbox_to_anchor=(0.5,-0.085),ncol=3,fontsize=9,labelcolor=SEC)
frame(fig,ax,'Every plant changes place when you switch the measure',
 'The same 74 plants, ranked two ways. Lines cross the full height of the chart: the top 10 by rate and the top 10 by\nvolume share no plant at all — the two queues are disjoint for the first 20 positions.',ty=1.115,sy=1.085,srcy=-0.115)
fig.savefig('fig2_slope_rank_switch.png')
