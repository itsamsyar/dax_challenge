import pandas as pd, numpy as np
from style import *
p=pd.read_pickle('plants.pkl'); tot=p.nrw_yr.sum()
x=np.arange(1,75)
byv=p.sort_values('nrw_yr',ascending=False).nrw_yr.cumsum().values/tot*100
byp=p.sort_values('nrw_pct',ascending=False).nrw_yr.cumsum().values/tot*100
fig,ax=plt.subplots(figsize=(10,6.4)); fig.subplots_adjust(top=0.80,bottom=0.14)
ax.plot(x,byv,color=S1,lw=2.4,solid_capstyle='round',label='Crews sent in NRW-volume order')
ax.plot(x,byp,color=S2,lw=2.4,solid_capstyle='round',label='Crews sent in NRW-rate % order')
ax.plot(x,x/74*100,color=NEUT,lw=1.6,label='No prioritisation (proportional reference)')
k=10
ax.plot([k,k],[0,byv[k-1]],color=AX,lw=0.9,zorder=1)
for y,c,lab in [(byv[k-1],S1,f'{byv[k-1]:.0f}% of all lost water'),(byp[k-1],S2,f'{byp[k-1]:.0f}%')]:
    ax.scatter([k],[y],s=70,c=c,edgecolors=SURF,linewidths=2,zorder=6)
ax.annotate(f'First 10 plants in volume order\nrecover {byv[k-1]:.0f}% of all water lost',(k,byv[k-1]),xytext=(16,byv[k-1]-3),
            fontsize=9.5,color=SEC,va='top',arrowprops=dict(arrowstyle='-',color=AX,lw=0.8))
ax.annotate(f'the same 10 crew-weeks in rate order\nrecover {byp[k-1]:.0f}%',(k,byp[k-1]),xytext=(16,byp[k-1]+9),
            fontsize=9.5,color=SEC,arrowprops=dict(arrowstyle='-',color=AX,lw=0.8))
ax.set_xlim(0,74); ax.set_ylim(0,102); ax.grid(True); ax.set_axisbelow(True)
ax.set_xlabel('Number of plants repaired  (in the order each measure recommends)')
ax.set_ylabel('Share of PAIP’s total NRW volume covered  (%)')
ax.yaxis.set_major_formatter(lambda v,_: f'{v:.0f}%')
ax.legend(loc='lower right',fontsize=9.5,labelcolor=SEC,borderpad=0.9)
frame(fig,ax,'The same repair budget, two very different results',
 'Cumulative share of PAIP’s annual water loss addressed as crews work down each ranking. Volume order front-loads the\nrecovery; rate order spends its first ten visits on plants that together hold 4% of the losses.')
fig.savefig('fig5_capture_curve.png')
