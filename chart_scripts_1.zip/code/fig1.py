import pandas as pd, numpy as np
from adjustText import adjust_text
from style import *
p=pd.read_pickle('plants.pkl')
fig,ax=plt.subplots(figsize=(10,6.6))
fig.subplots_adjust(top=0.80,bottom=0.16)
ax.set_yscale('log'); ax.grid(True); ax.set_axisbelow(True)
mx,my=p.nrw_pct.median(),p.nrw_yr.median()
ax.axvline(mx,color=AX,lw=0.8,zorder=1); ax.axhline(my,color=AX,lw=0.8,zorder=1)
big=p.nlargest(5,'nrw_yr'); hi=p.nlargest(5,'nrw_pct')
rest=p[~p.Nama_Loji.isin(set(big.Nama_Loji)|set(hi.Nama_Loji))]
ax.scatter(rest.nrw_pct,rest.nrw_yr,s=46,c=NEUT,edgecolors=SURF,linewidths=1.6,zorder=3,label='Other plants (64)')
ax.scatter(big.nrw_pct,big.nrw_yr,s=95,c=S1,edgecolors=SURF,linewidths=1.6,zorder=5,label='Top 5 by NRW volume  (where the water is)')
ax.scatter(hi.nrw_pct,hi.nrw_yr,s=95,c=S2,edgecolors=SURF,linewidths=1.6,zorder=5,label='Top 5 by NRW rate %  (where the alarm is)')
ax.set_xlim(24,70); ax.set_ylim(1.2e5,4.2e7)
txt=[ax.text(r.nrw_pct,r.nrw_yr,r.Nama_Loji,fontsize=8.5,color=SEC) for _,r in pd.concat([big,hi]).iterrows()]
adjust_text(txt,ax=ax,expand=(1.25,1.6),arrowprops=dict(arrowstyle='-',color=AX,lw=0.7))
import matplotlib.transforms as mt
bx=mt.blended_transform_factory(ax.transData,ax.transAxes)
ax.text(mx+0.6,0.985,'median rate  38.2%',fontsize=8.5,color=MUT,transform=bx,va='top')
by=mt.blended_transform_factory(ax.transAxes,ax.transData)
ax.text(0.012,my*1.12,'median volume',fontsize=8.5,color=MUT,ha='left',transform=by)
ax.set_xlabel('NRW rate  —  % of water produced that is never billed')
ax.set_ylabel('NRW volume  —  m³ lost per year  (log scale)')
ax.yaxis.set_major_formatter(lambda v,_: f'{v/1e6:g}M' if v>=1e6 else f'{v/1e3:g}k')
ax.legend(loc='lower left',fontsize=9,labelcolor=SEC,handletextpad=0.6,borderpad=0.8)
frame(fig,ax,'The two measures point at different plants',
 'Each dot is one PAIP plant, totals over 36 months. The five biggest water losers (blue) all sit below the median loss rate;\nthe five worst loss rates (orange) are all small plants. Spearman ρ between rate and volume = −0.54: not merely weak, inverted.')
fig.savefig('fig1_scatter_rate_vs_volume.png')
