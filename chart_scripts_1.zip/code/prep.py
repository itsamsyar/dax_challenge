import pandas as pd, numpy as np
SRC='/root/.claude/uploads/32fc6b00-b24f-5357-b11f-d4619ec2d2c1/e4d7ab5c-prasiswazah_1.csv'
df=pd.read_csv(SRC, thousands=',')
df['Tarikh']=pd.to_datetime(df['Tarikh'], format='%d/%m/%Y')
# recompute NRW from raw volumes (don't trust the pre-formatted % string)
df['NRW_m3_calc']=df['Pengeluaran_m3']-df['Jumlah_Dibilkan_m3']
print('max abs diff vs published NRW_m3:', (df['NRW_m3_calc']-df['NRW_m3']).abs().max())
df['NRW_pct_calc']=df['NRW_m3_calc']/df['Pengeluaran_m3']*100
pub=df['NRW_Peratus'].str.rstrip('%').astype(float)
print('max abs diff vs published NRW_%:', (df['NRW_pct_calc']-pub).abs().max())
print('missing:', df[['Pengeluaran_m3','Jumlah_Dibilkan_m3','NRW_m3']].isna().sum().to_dict())
print('negative NRW rows:', (df['NRW_m3_calc']<0).sum())
print('plant-district uniqueness:', df.groupby('Nama_Loji')['Daerah'].nunique().max())
print('months per plant:', df.groupby('Nama_Loji').size().describe()[['min','max']].to_dict())
df.to_pickle('tidy.pkl')
