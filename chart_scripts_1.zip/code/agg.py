import pandas as pd, numpy as np
from scipy.stats import spearmanr, kendalltau
df=pd.read_pickle('tidy.pkl')
p=df.groupby(['Nama_Loji','Daerah','Jenis_Kawasan'],as_index=False).agg(
    prod=('Pengeluaran_m3','sum'), billed=('Jumlah_Dibilkan_m3','sum'), nrw=('NRW_m3','sum'),
    km=('Panjang_Paip_km','mean'), cap=('Kapasiti_Loji_m3_hari','mean'), pop=('Populasi_Dilayan','mean'))
p['nrw_pct']=p['nrw']/p['prod']*100
p['nrw_yr']=p['nrw']/3            # m3/year
p['prod_yr']=p['prod']/3
p['rank_pct']=p['nrw_pct'].rank(ascending=False,method='first').astype(int)
p['rank_vol']=p['nrw_yr'].rank(ascending=False,method='first').astype(int)
p['shift']=p['rank_pct']-p['rank_vol']   # +ve = volume ranks it MORE urgent than % does
rho=spearmanr(p['nrw_pct'],p['nrw_yr']); tau=kendalltau(p['rank_pct'],p['rank_vol'])
print(f"n={len(p)}  spearman rho={rho.statistic:.3f} p={rho.pvalue:.2g}  kendall tau={tau.statistic:.3f}")
print('NRW pct range {:.1f}-{:.1f} median {:.1f}'.format(p.nrw_pct.min(),p.nrw_pct.max(),p.nrw_pct.median()))
print('NRW vol/yr range {:,.0f}-{:,.0f}'.format(p.nrw_yr.min(),p.nrw_yr.max()))
for k in (5,10,15,20):
    a=set(p.nsmallest(k,'rank_pct').Nama_Loji); b=set(p.nsmallest(k,'rank_vol').Nama_Loji)
    print(f'top{k}: overlap {len(a&b)}/{k}')
# capture curves
tot=p['nrw_yr'].sum()
byvol=p.sort_values('nrw_yr',ascending=False)['nrw_yr'].cumsum()/tot*100
bypct=p.sort_values('nrw_pct',ascending=False)['nrw_yr'].cumsum()/tot*100
for k in (5,10,15,20):
    print(f'k={k}: volume-order captures {byvol.iloc[k-1]:.1f} pct vs rate-order {bypct.iloc[k-1]:.1f} pct')
print('\nbiggest movers (rate hides them):'); print(p.nlargest(6,'shift')[['Nama_Loji','Daerah','nrw_pct','nrw_yr','rank_pct','rank_vol','shift']].to_string(index=False))
print('\nrate over-promotes:'); print(p.nsmallest(6,'shift')[['Nama_Loji','Daerah','nrw_pct','nrw_yr','rank_pct','rank_vol','shift']].to_string(index=False))
# per-year stability
yr=df.groupby(['Nama_Loji','Tahun'],as_index=False).agg(produced=('Pengeluaran_m3','sum'),nrw=('NRW_m3','sum'))
yr['pct']=yr.nrw/yr.produced*100
yr['r_pct']=yr.groupby('Tahun')['pct'].rank(ascending=False,method='first')
yr['r_vol']=yr.groupby('Tahun')['nrw'].rank(ascending=False,method='first')
print('\nper-year spearman(rank_pct,rank_vol):')
for y,g in yr.groupby('Tahun'): print(' ',y, round(spearmanr(g.pct,g.nrw).statistic,3))
p.to_pickle('plants.pkl'); yr.to_pickle('yearly.pkl')
p.sort_values('rank_vol').to_csv('plant_summary.csv',index=False)
