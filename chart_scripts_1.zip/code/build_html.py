import json
d=open('data.json').read()
html = r'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>PAIP NRW — rate vs volume</title>
<style>
:root{--surface-1:#fcfcfb;--plane:#f9f9f7;--text-primary:#0b0b0b;--text-secondary:#52514e;--muted:#898781;
--grid:#e1e0d9;--axis:#c3c2b7;--s1:#2a78d6;--s2:#eb6834;--neutral:#c9c8c1;--border:rgba(11,11,11,0.10);}
:root[data-theme="dark"]{--surface-1:#1a1a19;--plane:#0d0d0d;--text-primary:#fff;--text-secondary:#c3c2b7;
--muted:#898781;--grid:#2c2c2a;--axis:#383835;--s1:#3987e5;--s2:#d95926;--neutral:#4a4a46;--border:rgba(255,255,255,0.10);}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--surface-1:#1a1a19;--plane:#0d0d0d;--text-primary:#fff;
--text-secondary:#c3c2b7;--muted:#898781;--grid:#2c2c2a;--axis:#383835;--s1:#3987e5;--s2:#d95926;--neutral:#4a4a46;--border:rgba(255,255,255,0.10);}}
*{box-sizing:border-box}
body{margin:0;background:var(--plane);color:var(--text-primary);font:15px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif;}
.wrap{max-width:1180px;margin:0 auto;padding:36px 24px 80px;}
header h1{font-size:26px;margin:0 0 6px;letter-spacing:-.01em}
header p{color:var(--text-secondary);margin:0;max-width:74ch}
.bar{display:flex;gap:10px;align-items:center;margin:22px 0 8px;flex-wrap:wrap}
button{font:inherit;font-size:13px;padding:7px 13px;border-radius:8px;border:1px solid var(--border);
background:var(--surface-1);color:var(--text-secondary);cursor:pointer}
button[aria-pressed="true"]{color:var(--text-primary);border-color:var(--axis);font-weight:600}
.card{background:var(--surface-1);border:1px solid var(--border);border-radius:14px;padding:22px 24px 18px;margin:18px 0}
.card h2{font-size:17px;margin:0 0 4px}
.card p.sub{color:var(--text-secondary);font-size:13.5px;margin:0 0 14px;max-width:88ch}
svg{display:block;width:100%;height:auto;overflow:visible}
.gl{stroke:var(--grid);stroke-width:1}
.ax{stroke:var(--axis);stroke-width:1}
.tick{fill:var(--muted);font-size:11px}
.lab{fill:var(--text-secondary);font-size:11.5px}
.axtitle{fill:var(--text-secondary);font-size:12px}
.legend{display:flex;gap:18px;flex-wrap:wrap;font-size:12.5px;color:var(--text-secondary);margin:2px 0 12px}
.legend i{display:inline-block;width:11px;height:11px;border-radius:3px;margin-right:6px;vertical-align:-1px}
.tip{position:fixed;pointer-events:none;opacity:0;transition:opacity .09s;background:var(--surface-1);
border:1px solid var(--border);border-radius:10px;padding:9px 11px;font-size:12.5px;color:var(--text-primary);
box-shadow:0 6px 22px rgba(0,0,0,.14);z-index:10;max-width:260px}
.tip b{display:block;font-size:13px;margin-bottom:3px}
.tip span{display:block;color:var(--text-secondary);margin-top:2px}
table{border-collapse:collapse;width:100%;font-size:13px;font-variant-numeric:tabular-nums}
th,td{padding:7px 10px;text-align:right;border-bottom:1px solid var(--grid)}
th:first-child,td:first-child,th:nth-child(2),td:nth-child(2){text-align:left}
th{color:var(--text-secondary);font-weight:600;cursor:pointer;user-select:none;white-space:nowrap}
tbody tr:hover{background:var(--plane)}
.note{color:var(--muted);font-size:12px;margin-top:10px}
.hidden{display:none}
</style></head><body>
<div class="wrap">
<header>
<h1>Non-revenue water at PAIP: two ways of measuring the same loss</h1>
<p>74 treatment plants across 11 Pahang districts, 36 monthly records each (Jan 2023 – Dec 2025). Loss is shown as a rate — the share of treated water never billed — and as a volume, the cubic metres actually lost. Hover any mark for detail.</p>
</header>
<div class="bar">
  <button id="themeBtn" aria-pressed="false">Toggle dark mode</button>
  <button id="tableBtn" aria-pressed="false">Show data table</button>
</div>

<div class="card"><h2>1 · The two measures point at different plants</h2>
<p class="sub">Each dot is one plant. Horizontal position is its loss rate, vertical position the volume it loses each year (log scale). Spearman ρ = −0.54 — the two measures are inversely related.</p>
<div class="legend"><span><i style="background:var(--s1)"></i>Top 10 by NRW volume</span><span><i style="background:var(--s2)"></i>Top 10 by NRW rate %</span><span><i style="background:var(--neutral)"></i>Other plants</span></div>
<svg id="c1" viewBox="0 0 980 520"></svg></div>

<div class="card"><h2>2 · Every plant changes place when the measure changes</h2>
<p class="sub">The same 74 plants ranked twice. The top 10 by rate and the top 10 by volume have no plant in common. Hover a line to trace one plant.</p>
<div class="legend"><span><i style="background:var(--s1)"></i>Top 10 by volume</span><span><i style="background:var(--s2)"></i>Top 10 by rate</span><span><i style="background:var(--neutral)"></i>Other plants</span></div>
<svg id="c2" viewBox="0 0 980 900"></svg></div>

<div class="card"><h2>3 · Two repair queues, no plant in common</h2>
<p class="sub">Top 15 under each measure. The parenthetical on each bar is that plant's position under the <em>other</em> measure.</p>
<svg id="c3" viewBox="0 0 1130 500"></svg></div>

<div class="card"><h2>4 · The plants that move furthest between the two rankings</h2>
<p class="sub">Twelve largest movers in each direction. Blue: volume calls it urgent, rate does not. Orange: the reverse.</p>
<svg id="c4" viewBox="0 0 980 620"></svg></div>

<div class="card"><h2>5 · The same repair budget, two very different results</h2>
<p class="sub">Cumulative share of PAIP's annual water loss covered as crews work down each ranking. Hover to read either curve at any number of plants.</p>
<div class="legend"><span><i style="background:var(--s1)"></i>Volume order</span><span><i style="background:var(--s2)"></i>Rate order</span><span><i style="background:var(--neutral)"></i>No prioritisation</span></div>
<svg id="c5" viewBox="0 0 980 470"></svg></div>

<div class="card hidden" id="tableCard"><h2>All 74 plants</h2>
<p class="sub">Click a column heading to sort. Volumes are annual averages over the 36-month period.</p>
<div style="max-height:560px;overflow:auto"><table id="tbl"><thead><tr>
<th data-k="name">Plant</th><th data-k="district">District</th><th data-k="pct">NRW rate %</th>
<th data-k="nrw">NRW m³/yr</th><th data-k="share">Share of total %</th>
<th data-k="rp">Rank by rate</th><th data-k="rv">Rank by volume</th><th data-k="shift">Rank shift</th>
</tr></thead><tbody></tbody></table></div></div>

<p class="note">Source: PAIP monthly plant records, Jan 2023 – Dec 2025 (74 plants × 36 months = 2,664 plant-month records). Rate is computed volume-weighted: total NRW ÷ total production over the period.</p>
</div>
<div class="tip" id="tip"></div>
<script>
const DATA = __DATA__;
const P = DATA.plants;
const topV = new Set(P.filter(d=>d.rv<=10).map(d=>d.name));
const topR = new Set(P.filter(d=>d.rp<=10).map(d=>d.name));
const cs = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const fmtM = v => v>=1e6 ? (v/1e6).toFixed(1)+'M' : Math.round(v/1e3)+'k';
const NS='http://www.w3.org/2000/svg';
const el=(t,a={})=>{const e=document.createElementNS(NS,t);for(const k in a)e.setAttribute(k,a[k]);return e;};
const tip=document.getElementById('tip');
function showTip(e,html){tip.innerHTML=html;tip.style.opacity=1;moveTip(e);}
function moveTip(e){const r=tip.getBoundingClientRect();let x=e.clientX+14,y=e.clientY+14;
 if(x+r.width>innerWidth-8)x=e.clientX-r.width-14; if(y+r.height>innerHeight-8)y=e.clientY-r.height-14;
 tip.style.left=x+'px';tip.style.top=y+'px';}
function hideTip(){tip.style.opacity=0;}
function bind(node,html){node.addEventListener('mousemove',e=>showTip(e,html));node.addEventListener('mouseleave',hideTip);}
const pTip=d=>`<b>${d.name}</b><span>${d.district} · ${d.area}</span><span style="display:block;margin-top:5px">Loss rate <b style="display:inline">${d.pct}%</b> — rank ${d.rp} of 74</span><span>Loss volume <b style="display:inline">${d.nrw.toLocaleString()} m³/yr</b> — rank ${d.rv} of 74</span><span>${d.share}% of all water PAIP loses</span>`;

function clear(id){const s=document.getElementById(id);while(s.firstChild)s.removeChild(s.firstChild);return s;}
function txt(s,x,y,t,cls,extra={}){const e=el('text',Object.assign({x:x,y:y,class:cls||'lab'},extra));e.textContent=t;s.appendChild(e);return e;}

/* ---------- 1. scatter ---------- */
function c1(){const s=clear('c1');const W=980,H=520,m={t:16,r:150,b:52,l:64};
 const xs=v=>m.l+(v-24)/(62-24)*(W-m.l-m.r);
 const y0=Math.log10(1.4e5),y1=Math.log10(3.2e7);
 const ys=v=>H-m.b-(Math.log10(v)-y0)/(y1-y0)*(H-m.t-m.b);
 [30,40,50,60].forEach(v=>{s.appendChild(el('line',{x1:xs(v),x2:xs(v),y1:m.t,y2:H-m.b,class:'gl'}));txt(s,xs(v),H-m.b+18,v+'%','tick',{'text-anchor':'middle'});});
 [2e5,5e5,1e6,3e6,1e7,3e7].forEach(v=>{s.appendChild(el('line',{x1:m.l,x2:W-m.r,y1:ys(v),y2:ys(v),class:'gl'}));txt(s,m.l-10,ys(v)+4,fmtM(v),'tick',{'text-anchor':'end'});});
 txt(s,m.l,H-14,'NRW rate — % of produced water never billed','axtitle');
 txt(s,m.l-10,m.t-6,'m³ lost per year','axtitle',{'text-anchor':'start',x:m.l-56});
 P.forEach(d=>{const hi=topV.has(d.name)||topR.has(d.name);
  const c=topV.has(d.name)?cs('--s1'):(topR.has(d.name)?cs('--s2'):cs('--neutral'));
  const g=el('circle',{cx:xs(d.pct),cy:ys(d.nrw),r:hi?7:5,fill:c,stroke:cs('--surface-1'),'stroke-width':2});
  bind(g,pTip(d));s.appendChild(g);});
 const med=38.2; s.appendChild(el('line',{x1:xs(med),x2:xs(med),y1:m.t,y2:H-m.b,class:'ax'}));
 txt(s,xs(med)+6,m.t+12,'median rate 38.2%','tick');
 // label the extremes
 P.filter(d=>d.rv<=5).sort((a,b)=>a.rv-b.rv).forEach((d,i)=>txt(s,xs(d.pct)+11,ys(d.nrw)+(i%2?-11:15),d.name,'lab'));
 P.filter(d=>d.rp<=4).sort((a,b)=>a.rp-b.rp).forEach((d,i)=>txt(s,xs(d.pct)+11,ys(d.nrw)+(i%2?-11:15),d.name,'lab'));
}
/* ---------- 2. slope ---------- */
function c2(){const s=clear('c2');const W=980,H=900,top=52,bot=H-30,xa=330,xb=650;
 const y=r=>top+(r-1)/73*(bot-top);
 txt(s,xa,26,'RANKED BY NRW RATE %','lab',{'text-anchor':'middle',fill:cs('--s2'),'font-weight':700});
 txt(s,xb,26,'RANKED BY NRW VOLUME','lab',{'text-anchor':'middle',fill:cs('--s1'),'font-weight':700});
 const layer=el('g');s.appendChild(layer);
 P.forEach(d=>{const hi=topV.has(d.name)||topR.has(d.name);
  const c=topV.has(d.name)?cs('--s1'):(topR.has(d.name)?cs('--s2'):cs('--neutral'));
  const g=el('g',{});
  const ln=el('line',{x1:xa,y1:y(d.rp),x2:xb,y2:y(d.rv),stroke:c,'stroke-width':hi?2.4:1.2,'stroke-linecap':'round',opacity:hi?1:0.55});
  g.appendChild(ln);
  g.appendChild(el('circle',{cx:xa,cy:y(d.rp),r:hi?4:2.6,fill:c}));
  g.appendChild(el('circle',{cx:xb,cy:y(d.rv),r:hi?4:2.6,fill:c}));
  const hit=el('line',{x1:xa,y1:y(d.rp),x2:xb,y2:y(d.rv),stroke:'transparent','stroke-width':11});
  g.appendChild(hit);
  hit.addEventListener('mousemove',e=>{showTip(e,pTip(d));ln.setAttribute('stroke-width',3.4);ln.setAttribute('opacity',1);});
  hit.addEventListener('mouseleave',()=>{hideTip();ln.setAttribute('stroke-width',hi?2.4:1.2);ln.setAttribute('opacity',hi?1:0.55);});
  layer.appendChild(g);
  if(hi){txt(s,xa-12,y(d.rp)+4,d.rp+'  '+d.name,'lab',{'text-anchor':'end',fill:topR.has(d.name)?cs('--text-secondary'):cs('--muted')});
         txt(s,xb+12,y(d.rv)+4,d.rv+'  '+d.name,'lab',{fill:topV.has(d.name)?cs('--text-secondary'):cs('--muted')});}
 });
}
/* ---------- 3. paired bars ---------- */
function c3(){const s=clear('c3');const W=980,H=500;
 const panels=[{x0:150,x1:400,key:'rp',color:'--s2',title:'Ranked by NRW rate — top 15',val:d=>d.pct,max:60,f:d=>d.pct.toFixed(1)+'%',other:d=>'(volume rank '+d.rv+')'},
               {x0:770,x1:1000,key:'rv',color:'--s1',title:'Ranked by NRW volume — top 15',val:d=>d.nrw,max:25e6,f:d=>fmtM(d.nrw),other:d=>'(rate rank '+d.rp+')'}];
 panels.forEach(pn=>{
  const list=P.filter(d=>d[pn.key]<=15).sort((a,b)=>a[pn.key]-b[pn.key]);
  txt(s,pn.x0,26,pn.title,'lab',{fill:cs(pn.color),'font-weight':700});
  list.forEach((d,i)=>{const y=56+i*28,w=pn.val(d)/pn.max*(pn.x1-pn.x0);
   txt(s,pn.x0-10,y+9,d.name,'lab',{'text-anchor':'end',fill:cs('--text-secondary')});
   const r=el('rect',{x:pn.x0,y:y,width:Math.max(w,2),height:13,rx:3,fill:cs(pn.color)});
   bind(r,pTip(d));s.appendChild(r);
   txt(s,pn.x0+w+8,y+11,pn.f(d),'lab',{fill:cs('--text-secondary')});
   txt(s,pn.x0+w+52,y+11,pn.other(d),'tick');});
  s.appendChild(el('line',{x1:pn.x0,x2:pn.x0,y1:50,y2:56+15*28-8,class:'ax'}));
 });
}
/* ---------- 4. rank shift ---------- */
function c4(){const s=clear('c4');const W=980,H=620,cx=490;
 const up=[...P].sort((a,b)=>b.shift-a.shift).slice(0,12);
 const dn=[...P].sort((a,b)=>a.shift-b.shift).slice(0,12).reverse();
 const rows=up.concat(dn.reverse());
 const sc=v=>v/75*300;
 txt(s,cx-14,20,'← rate calls it urgent','lab',{'text-anchor':'end',fill:cs('--s2'),'font-weight':700});
 txt(s,cx+14,20,'volume calls it urgent →','lab',{fill:cs('--s1'),'font-weight':700});
 rows.forEach((d,i)=>{const y=38+i*23,w=sc(Math.abs(d.shift)),pos=d.shift>0;
  const r=el('rect',{x:pos?cx:cx-w,y:y,width:Math.max(w,2),height:12,rx:3,fill:pos?cs('--s1'):cs('--s2')});
  bind(r,pTip(d));s.appendChild(r);
  txt(s,pos?cx-8:cx+8,y+10,d.name,'lab',{'text-anchor':pos?'end':'start',fill:cs('--text-primary')});
  txt(s,pos?cx+w+8:cx-w-8,y+10,`rate #${d.rp} → volume #${d.rv}  ·  ${d.pct}%  ·  ${fmtM(d.nrw)} m³/yr`,'tick',{'text-anchor':pos?'start':'end'});});
 s.appendChild(el('line',{x1:cx,x2:cx,y1:30,y2:38+rows.length*23,class:'ax'}));
}
/* ---------- 5. capture curve ---------- */
function c5(){const s=clear('c5');const W=980,H=470,m={t:16,r:30,b:52,l:60};
 const xs=i=>m.l+(i)/73*(W-m.l-m.r), ys=v=>H-m.b-v/100*(H-m.t-m.b);
 [0,25,50,75,100].forEach(v=>{s.appendChild(el('line',{x1:m.l,x2:W-m.r,y1:ys(v),y2:ys(v),class:'gl'}));txt(s,m.l-10,ys(v)+4,v+'%','tick',{'text-anchor':'end'});});
 [1,10,20,30,40,50,60,74].forEach(v=>txt(s,xs(v-1),H-m.b+18,v,'tick',{'text-anchor':'middle'}));
 txt(s,m.l,H-14,'Number of plants repaired, in the order each measure recommends','axtitle');
 const path=(a,c)=>{let d='';a.forEach((v,i)=>d+=(i?'L':'M')+xs(i).toFixed(1)+','+ys(v).toFixed(1));
   s.appendChild(el('path',{d:d,fill:'none',stroke:c,'stroke-width':2.4,'stroke-linecap':'round'}));};
 let ref=[];for(let i=0;i<74;i++)ref.push((i+1)/74*100);
 path(ref,cs('--neutral'));path(DATA.capPct,cs('--s2'));path(DATA.capVol,cs('--s1'));
 const cross=el('line',{x1:0,x2:0,y1:m.t,y2:H-m.b,stroke:cs('--axis'),'stroke-width':1,opacity:0});
 const d1=el('circle',{r:5,fill:cs('--s1'),stroke:cs('--surface-1'),'stroke-width':2,opacity:0});
 const d2=el('circle',{r:5,fill:cs('--s2'),stroke:cs('--surface-1'),'stroke-width':2,opacity:0});
 s.appendChild(cross);s.appendChild(d1);s.appendChild(d2);
 const hit=el('rect',{x:m.l,y:m.t,width:W-m.l-m.r,height:H-m.t-m.b,fill:'transparent'});
 s.appendChild(hit);
 hit.addEventListener('mousemove',e=>{const pt=s.getBoundingClientRect();
  const rel=(e.clientX-pt.left)/pt.width*W;let i=Math.round((rel-m.l)/(W-m.l-m.r)*73);
  i=Math.max(0,Math.min(73,i));
  cross.setAttribute('x1',xs(i));cross.setAttribute('x2',xs(i));cross.setAttribute('opacity',1);
  d1.setAttribute('cx',xs(i));d1.setAttribute('cy',ys(DATA.capVol[i]));d1.setAttribute('opacity',1);
  d2.setAttribute('cx',xs(i));d2.setAttribute('cy',ys(DATA.capPct[i]));d2.setAttribute('opacity',1);
  showTip(e,`<b>After ${i+1} plant${i?'s':''} repaired</b><span style="display:block;margin-top:4px">Volume order: <b style="display:inline">${DATA.capVol[i].toFixed(1)}%</b> of all NRW covered</span><span>Rate order: <b style="display:inline">${DATA.capPct[i].toFixed(1)}%</b></span>`);});
 hit.addEventListener('mouseleave',()=>{hideTip();[cross,d1,d2].forEach(n=>n.setAttribute('opacity',0));});
}
/* ---------- table ---------- */
let sortK='rv',asc=true;
function table(){const tb=document.querySelector('#tbl tbody');tb.innerHTML='';
 const rows=[...P].sort((a,b)=>{const x=a[sortK],y=b[sortK];const v=typeof x==='string'?x.localeCompare(y):x-y;return asc?v:-v;});
 rows.forEach(d=>{const tr=document.createElement('tr');
  tr.innerHTML=`<td>${d.name}</td><td>${d.district}</td><td>${d.pct}</td><td>${d.nrw.toLocaleString()}</td><td>${d.share}</td><td>${d.rp}</td><td>${d.rv}</td><td>${d.shift>0?'+':''}${d.shift}</td>`;
  tb.appendChild(tr);});}
document.querySelectorAll('#tbl th').forEach(th=>th.addEventListener('click',()=>{
 const k=th.dataset.k; asc = (k===sortK)? !asc : true; sortK=k; table();}));

function drawAll(){c1();c2();c3();c4();c5();}
drawAll();table();
const tb=document.getElementById('themeBtn');
tb.addEventListener('click',()=>{const dark=document.documentElement.getAttribute('data-theme')==='dark';
 document.documentElement.setAttribute('data-theme',dark?'light':'dark');tb.setAttribute('aria-pressed',String(!dark));drawAll();});
const tbtn=document.getElementById('tableBtn');
tbtn.addEventListener('click',()=>{const c=document.getElementById('tableCard');const h=c.classList.toggle('hidden');
 tbtn.setAttribute('aria-pressed',String(!h));tbtn.textContent=h?'Show data table':'Hide data table';});
</script></body></html>'''
open('nrw_objective1_dashboard.html','w').write(html.replace('__DATA__', d))
print('written')
