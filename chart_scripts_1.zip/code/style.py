import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
SURF='#fcfcfb'; INK='#0b0b0b'; SEC='#52514e'; MUT='#898781'; GRID='#e1e0d9'; AX='#c3c2b7'
S1='#2a78d6'; S2='#eb6834'; S3='#1baf7a'; NEUT='#c9c8c1'
plt.rcParams.update({
 'figure.facecolor':SURF,'axes.facecolor':SURF,'savefig.facecolor':SURF,
 'font.family':'DejaVu Sans','font.size':10,
 'text.color':INK,'axes.labelcolor':SEC,'xtick.color':MUT,'ytick.color':MUT,
 'axes.edgecolor':AX,'axes.linewidth':0.8,'axes.spines.top':False,'axes.spines.right':False,
 'grid.color':GRID,'grid.linewidth':0.8,'grid.linestyle':'-',
 'xtick.major.size':0,'ytick.major.size':0,'legend.frameon':False,
 'figure.dpi':200,'savefig.bbox':'tight','savefig.pad_inches':0.35})
def title(ax,t,sub=None):
    ax.set_title(t,loc='left',fontsize=13,fontweight='bold',color=INK,pad=18 if sub else 10)
    if sub: ax.text(0,1.02,sub,transform=ax.transAxes,fontsize=9.5,color=SEC,va='bottom')

def frame(fig, ax, t, sub, source='Source: PAIP monthly plant records, Jan 2023 – Dec 2025 (74 plants × 36 months = 2,664 plant-month records).', ty=1.20, sy=1.13, srcy=-0.19):
    ax.text(0.0,ty,t,fontsize=14,fontweight='bold',color=INK,va='bottom',ha='left',transform=ax.transAxes)
    ax.text(0.0,sy,sub,fontsize=9.5,color=SEC,va='top',ha='left',transform=ax.transAxes,linespacing=1.5)
    ax.text(0.0,srcy,source,fontsize=8,color=MUT,va='top',ha='left',transform=ax.transAxes)
