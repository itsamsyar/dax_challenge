import pandas as pd, numpy as np
from style import *
p=pd.read_pickle('plants.pkl')
fig,axes=plt.subplots(1,2,figsize=(13,6.8)); fig.subplots_adjust(top=0.78,wspace=0.55,bottom=0.10)
a,b=axes
r=p.nsmallest(15,'rank_pct').iloc[::-1]
a.barh(range(15),r.nrw_pct,color=S2,height=0.52)
a.set_yticks(range(15)); a.set_yticklabels([f'{n}' for n in r.Nama_Loji],fontsize=9,color=SEC)
for i,(v,rk) in enumerate(zip(r.nrw_pct,r.rank_vol)):
    a.text(v+1.3,i,f'{v:.1f}%',va='center',fontsize=8.5,color=SEC)
    a.text(v+11,i,f'(volume rank {rk})',va='center',fontsize=8,color=MUT)
a.set_xlim(0,86); a.set_xticks([0,20,40,60]); a.set_xticklabels(['0','20%','40%','60%'])
a.set_title('Ranked by NRW rate  —  top 15',loc='left',fontsize=11,fontweight='bold',color=S2,pad=12)
a.set_xlabel('NRW as % of water produced')
v=p.nsmallest(15,'rank_vol').iloc[::-1]
b.barh(range(15),v.nrw_yr/1e6,color=S1,height=0.52)
b.set_yticks(range(15)); b.set_yticklabels([f'{n}' for n in v.Nama_Loji],fontsize=9,color=SEC)
for i,(val,rk) in enumerate(zip(v.nrw_yr/1e6,v.rank_pct)):
    b.text(val+0.7,i,f'{val:.1f}M',va='center',fontsize=8.5,color=SEC)
    b.text(val+4.6,i,f'(rate rank {rk})',va='center',fontsize=8,color=MUT)
b.set_xlim(0,40); b.set_xticks([0,10,20]); b.set_xticklabels(['0','10M','20M'])
b.set_title('Ranked by NRW volume  —  top 15',loc='left',fontsize=11,fontweight='bold',color=S1,pad=12)
b.set_xlabel('m³ lost per year')
for ax in axes:
    ax.grid(axis='x'); ax.set_axisbelow(True); ax.spines['left'].set_visible(False); ax.tick_params(axis='y',pad=6)
frame(fig,a,'Two repair queues, no plant in common',
 'The 15 most urgent plants under each measure. No plant appears on both lists. The best-placed plant on the rate list is\nonly 30th by volume; the best-placed plant on the volume list is only 24th by rate.',ty=1.30,sy=1.22,srcy=-0.16)
fig.savefig('fig3_top15_side_by_side.png')
