import pandas as pd, numpy as np
from scipy.stats import spearmanr
from style import *
yr=pd.read_pickle('yearly.pkl'); p=pd.read_pickle('plants.pkl')
topv=set(p.nsmallest(10,'rank_vol').Nama_Loji); topp=set(p.nsmallest(10,'rank_pct').Nama_Loji)
fig,axes=plt.subplots(1,3,figsize=(13,5.2),sharey=True); fig.subplots_adjust(top=0.74,bottom=0.16,wspace=0.10)
for ax,(y,g) in zip(axes,yr.groupby('Tahun')):
    rho=spearmanr(g.pct,g.nrw).statistic
    o=g[~g.Nama_Loji.isin(topv|topp)]; b=g[g.Nama_Loji.isin(topv)]; r=g[g.Nama_Loji.isin(topp)]
    ax.scatter(o.pct,o.nrw,s=30,c=NEUT,edgecolors=SURF,linewidths=1.3,zorder=3,label='Other plants')
    ax.scatter(b.pct,b.nrw,s=55,c=S1,edgecolors=SURF,linewidths=1.3,zorder=5,label='Top 10 by NRW volume')
    ax.scatter(r.pct,r.nrw,s=55,c=S2,edgecolors=SURF,linewidths=1.3,zorder=5,label='Top 10 by NRW rate %')
    ax.set_yscale('log'); ax.grid(True); ax.set_axisbelow(True)
    ax.set_title(str(y),loc='left',fontsize=12,fontweight='bold',color=INK,pad=8)
    ax.text(0.975,0.96,'Spearman ρ = −{:.2f}'.format(abs(rho)),transform=ax.transAxes,fontsize=9.5,color=SEC,va='top',ha='right')
    ax.set_xlim(22,66); ax.set_ylim(1.3e5,4.5e7); ax.set_xticks([30,40,50,60]); ax.set_xticklabels(['30%','40%','50%','60%'])
    ax.set_xlabel('NRW rate')
axes[0].set_ylabel('NRW volume — m³ per year  (log)')
axes[0].yaxis.set_major_formatter(lambda v,_: f'{v/1e6:g}M' if v>=1e6 else f'{v/1e3:g}k')
axes[0].legend(loc='lower left',fontsize=8.5,labelcolor=SEC,borderpad=0.7)
frame(fig,axes[0],'The divergence is structural, not a one-year quirk',
 'The same inverted relationship appears in each year separately: ρ = −0.54, −0.51, −0.54. The plants coloured here are the\nall-period top 10 on each measure — they hold their opposite corners in every year.',ty=1.32,sy=1.24,srcy=-0.24)
fig.savefig('fig6_year_stability.png')
